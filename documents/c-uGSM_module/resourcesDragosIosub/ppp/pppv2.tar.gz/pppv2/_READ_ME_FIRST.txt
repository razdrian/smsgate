copy the files:
    cp ppp/pears/* /etc/ppp/pears
    cp home/pi/* /home/pi

edit:
    /home/pi/startPPP and chose your shield model (a-gsm, c-uGSM or d-3G)
    /home/pi/stopPPP, same as above

    /etc/ppp/pears/a-gsm or /etc/ppp/pears/c-uGSM or /etc/ppp/pears/d-3G 
    and chose between SERIAL or USB connectivity

./startPPP will start the wireless communication. ifconfig, route -n and cat /etc/resolv.conf will provide to you additional information
new default route (via PPP0) will be efective! if you DON'T need this edit the pear file... 

./stopPPP will stop the wireless communication and restore the default route. ifconfig, route -n and cat /etc/resolv.conf...

This SOFTWARE is distributed is provide "AS IS" in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

Dragos Iosub, Bucharest 2015.
http://itbrainpower.net

